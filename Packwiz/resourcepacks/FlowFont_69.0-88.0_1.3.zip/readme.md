## FlowFont

[Minecraft][minecraft] 32x font resource pack.

### Contents

This resource pack replaces vanilla font textures with smooth 32x textures. Please note that some non-latin characters may be inaccurate.

### Installation

- Install directly via the [Modrinth App][modrinth:app] or [CurseForge App][curseforge:app].
- Or move the zip-File of your desired version to your resource packs folder. Zips can be downloaded from [Modrinth][modrinth] or [CurseForge][curseforge].

### Status

This project will be kept up-to-date with new game versions and receive fixes for bugs and inaccuracies, though both may take time depending on complexity. Support for characters beyond the vanilla chararacter sets is not planned.

### Version Compatibility

For info on version compatibility, please check the project uploads. Some features may not be available for all Minecraft versions due to technical limitations. Minecaft snapshots are generally not supported.

### Mod Compatibility

This resource pack is compatible with all mods that use the built-in font resources.

### Packaging

The packaging script downloads, builds and runs the [mcPkg][git:mcpkg] resource packager, which is used to interpret the source file structure and produce zip archives of the project resources.

[minecraft]: https://www.minecraft.net
[modrinth:app]: https://modrinth.com/app
[curseForge:app]: https://www.curseforge.com/download/app
[modrinth]: https://modrinth.com/resourcepack/flowfont
[curseforge]: https://www.curseforge.com/minecraft/texture-packs/flowfont
[git:mcpkg]: https://gitlab.com/iJustLeyxo/mcpkg

