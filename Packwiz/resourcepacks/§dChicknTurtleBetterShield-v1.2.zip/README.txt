
ChicknTurtle's Better Shield by ChicknTurtle
v1.2

https://curseforge.com/minecraft/texture-packs/chicknturtles-better-shield
https://modrinth.com/resourcepack/chicknturtles-better-shield

Credit to Vanilla Tweaks for HD shield banner textures.
https://vanillatweaks.net/
